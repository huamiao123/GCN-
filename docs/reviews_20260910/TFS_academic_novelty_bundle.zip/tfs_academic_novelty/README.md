# TFS 学术候选分析与数学参考

首先阅读 `TFS_academic_novelty_review_zh.md`。

`verify_candidates.py` 是两个候选机制的小规模 FP64 数学参考，不是 TFS/AMX 原生实现，不提供性能数据，也不证明学术新颖性。

```bash
python -m pip install numpy torch networkx
python verify_candidates.py --output verification_results.json
```

检查包括：source 生存区间与 slot 复用、loss/一阶梯度、固定 dropout mask 的链式梯度、共享开启成本最小割与穷举、统一成本下的全域支配关系以及合成图 frontier 宽度。

`verification_results.json` 是本次实际运行的输出。所有代理成本都是人为单位；其中 BF16 例子也不是项目的完整数值合同。验证脚本使用小型 dense reference，不适合直接在大图上运行。

公开文献和固定源码快照的来源位于主报告末尾。
