#!/usr/bin/env python3
"""Mathematical checks for two proposed TFS research mechanisms.

This is a small CPU/FP64 reference, NOT a TFS kernel, AMX implementation,
cache simulator, performance benchmark, or proof of academic originality.

Requirements: numpy, torch, networkx
Run: python verify_candidates.py --output verification_results.json
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import heapq
import itertools
import json
from pathlib import Path
from typing import Any

import networkx as nx
import numpy as np
import torch
import torch.nn.functional as F

SEED = 20260910
ATOL = 1e-10


@dataclass
class SlotPlan:
    order: np.ndarray
    starts: list[list[tuple[int, int]]]
    closes: list[list[tuple[int, int]]]
    edges: list[list[tuple[int, float]]]
    capacity: int
    active_counts: list[int]
    source_count: int


def compile_slots(s: np.ndarray, order: np.ndarray) -> SlotPlan:
    """Compile fixed source live intervals into reusable slots, one row per panel."""
    if s.ndim != 2 or not np.isfinite(s).all():
        raise ValueError("S must be a finite rank-2 matrix.")
    m, n = s.shape
    if order.shape != (m,) or sorted(order.tolist()) != list(range(m)):
        raise ValueError("order must be a permutation of all destination rows.")
    first = np.full(n, m, dtype=np.int64)
    last = np.full(n, -1, dtype=np.int64)
    neighbors = [np.flatnonzero(s[int(v)] != 0) for v in order]
    for t, srcs in enumerate(neighbors):
        first[srcs] = np.minimum(first[srcs], t)
        last[srcs] = t
    starts_by_time: list[list[int]] = [[] for _ in range(m)]
    closes_by_time: list[list[int]] = [[] for _ in range(m)]
    for u in range(n):
        if last[u] >= 0:
            starts_by_time[int(first[u])].append(u)
            closes_by_time[int(last[u])].append(u)
    starts: list[list[tuple[int, int]]] = []
    closes: list[list[tuple[int, int]]] = []
    edges: list[list[tuple[int, float]]] = []
    free: list[int] = []
    slots: dict[int, int] = {}
    capacity = 0
    active_counts: list[int] = []
    for t, row in enumerate(order):
        opened = []
        for u in starts_by_time[t]:
            if free:
                slot = heapq.heappop(free)
            else:
                slot = capacity
                capacity += 1
            slots[u] = slot
            opened.append((u, slot))
        active_counts.append(len(slots))
        starts.append(opened)
        edges.append([(slots[int(u)], float(s[int(row), int(u)])) for u in neighbors[t]])
        ended = [(u, slots[u]) for u in closes_by_time[t]]
        closes.append(ended)
        for u, slot in ended:
            del slots[u]
            heapq.heappush(free, slot)
    assert not slots
    assert capacity == max(active_counts, default=0)
    return SlotPlan(order.copy(), starts, closes, edges, capacity,
                    active_counts, int(np.count_nonzero(last >= 0)))


def stream_terminal(s: np.ndarray, h: np.ndarray, w: np.ndarray,
                    b: np.ndarray, labels: np.ndarray,
                    plan: SlotPlan) -> dict[str, Any]:
    """Primal + adjoint streaming with one load per used source; FP64 reference."""
    m, n = s.shape
    if m <= 0 or h.shape[0] != n or h.shape[1] != w.shape[0]:
        raise ValueError("Incompatible shapes or empty supervision set.")
    if b.shape != (w.shape[1],) or labels.shape != (m,):
        raise ValueError("Invalid bias or label shape.")
    if labels.min() < 0 or labels.max() >= w.shape[1]:
        raise ValueError("Label outside class range.")
    k = h.shape[1]
    hp = np.zeros((plan.capacity, k), dtype=np.float64)
    dp = np.zeros_like(hp)
    dh = np.zeros_like(h)
    dw = np.zeros_like(w)
    db = np.zeros_like(b)
    loss = 0.0
    loads = 0
    for t, row0 in enumerate(plan.order):
        row = int(row0)
        for u, slot in plan.starts[t]:
            hp[slot] = h[u]
            dp[slot].fill(0)
            loads += 1
        p = np.zeros(k, dtype=np.float64)
        for slot, weight in plan.edges[t]:
            p += weight * hp[slot]
        z = p @ w + b
        zmax = float(z.max())
        ez = np.exp(z - zmax)
        esum = float(ez.sum())
        loss += (zmax + np.log(esum) - float(z[labels[row]])) / m
        g = ez / esum
        g[labels[row]] -= 1.0
        g /= m
        dw += np.outer(p, g)
        db += g
        q = g @ w.T
        for slot, weight in plan.edges[t]:
            dp[slot] += weight * q
        for u, slot in plan.closes[t]:
            dh[u] = dp[slot]
    assert loads == plan.source_count
    return {"loss": loss, "dh": dh, "dw": dw, "db": db, "source_loads": loads}


def dense_autograd(s: np.ndarray, h: np.ndarray, w: np.ndarray,
                   b: np.ndarray, labels: np.ndarray) -> dict[str, Any]:
    ht = torch.tensor(h, dtype=torch.float64, requires_grad=True)
    wt = torch.tensor(w, dtype=torch.float64, requires_grad=True)
    bt = torch.tensor(b, dtype=torch.float64, requires_grad=True)
    st = torch.tensor(s, dtype=torch.float64)
    z = (st @ ht) @ wt + bt
    loss = F.cross_entropy(z, torch.tensor(labels, dtype=torch.long), reduction="mean")
    loss.backward()
    return {"loss": float(loss.detach()), "dh": ht.grad.numpy(),
            "dw": wt.grad.numpy(), "db": bt.grad.numpy(), "z": z.detach().numpy()}


def abs_error(a: Any, b: Any) -> float:
    return float(np.max(np.abs(np.asarray(a) - np.asarray(b))))


def mixed_forward_backward(s: np.ndarray, h: np.ndarray, w: np.ndarray,
                           b: np.ndarray, labels: np.ndarray,
                           transform: np.ndarray) -> dict[str, Any]:
    m = s.shape[0]
    aa, tt = ~transform, transform
    p_a = s[aa] @ h
    z = np.empty((m, w.shape[1]), dtype=np.float64)
    z[aa] = p_a @ w + b
    active = np.flatnonzero(np.any(s[tt] != 0, axis=0)) if tt.any() else np.array([], dtype=int)
    z[tt] = s[np.ix_(tt, active)] @ (h[active] @ w) + b
    zm = z.max(axis=1, keepdims=True)
    ez = np.exp(z - zm)
    denom = ez.sum(axis=1, keepdims=True)
    loss = float(np.mean(zm[:, 0] + np.log(denom[:, 0]) - z[np.arange(m), labels]))
    g = ez / denom
    g[np.arange(m), labels] -= 1.0
    g /= m
    r_t = s[tt].T @ g[tt]
    dw = p_a.T @ g[aa] + h.T @ r_t
    dh = s[aa].T @ (g[aa] @ w.T) + r_t @ w.T
    return {"loss": loss, "dh": dh, "dw": dw, "db": g.sum(axis=0), "z": z}


def model_cost(neighbors: list[list[int]], a: np.ndarray, b: np.ndarray,
               c: np.ndarray, transform: np.ndarray) -> float:
    active = {u for v, ns in enumerate(neighbors) if transform[v] for u in ns}
    return float(np.where(transform, b, a).sum() + sum(c[u] for u in active))


def mincut_choice(neighbors: list[list[int]], a: np.ndarray,
                  b: np.ndarray, c: np.ndarray) -> tuple[float, np.ndarray]:
    if np.any(a < 0) or np.any(b < 0) or np.any(c < 0):
        raise ValueError("This mapping expects nonnegative finite costs.")
    if not all(np.isfinite(x).all() for x in (a, b, c)):
        raise ValueError("Costs must be finite.")
    m = len(neighbors)
    graph = nx.DiGraph()
    src, sink = ("terminal", 0), ("terminal", 1)
    graph.add_nodes_from([src, sink])
    # Larger than the sum of all finite capacities: violating any dependency
    # is more expensive than at least one feasible cut.
    inf = float(a.sum() + b.sum() + c.sum() + 1.0)
    for v, ns in enumerate(neighbors):
        graph.add_edge(src, ("row", v), capacity=float(a[v]))
        graph.add_edge(("row", v), sink, capacity=float(b[v]))
        for u in ns:
            graph.add_edge(("row", v), ("source", u), capacity=inf)
    for u, value in enumerate(c):
        graph.add_edge(("source", u), sink, capacity=float(value))
    value, (left, _) = nx.minimum_cut(graph, src, sink)
    t = np.array([("row", v) in left for v in range(m)], dtype=bool)
    assert abs(float(value) - model_cost(neighbors, a, b, c, t)) < ATOL
    return float(value), t


def run_all() -> dict[str, Any]:
    torch.set_num_threads(1)
    rng = np.random.default_rng(SEED)
    max_stream = {x: 0.0 for x in ("loss", "dh", "dw", "db")}
    max_mixed = {x: 0.0 for x in ("loss", "dh", "dw", "db", "z")}
    fixed_mask_dz_error = 0.0
    stream_cases = 48
    mixed_cases = 0
    for case in range(stream_cases):
        m, n = int(rng.integers(2, 13)), int(rng.integers(5, 19))
        k, d = int(rng.integers(1, 12)), int(rng.integers(2, 14))
        s = rng.normal(size=(m, n)) * (rng.random((m, n)) < .25)
        if case % 3 == 0:
            s[0] = 0  # Empty selected row is a deliberate boundary case.
        h = rng.normal(size=(n, k)) * .4
        w = rng.normal(size=(k, d)) * .3
        b = rng.normal(size=d) * .1
        labels = rng.integers(d, size=m)
        plan = compile_slots(s, rng.permutation(m))
        got = stream_terminal(s, h, w, b, labels, plan)
        ref = dense_autograd(s, h, w, b, labels)
        for name in max_stream:
            max_stream[name] = max(max_stream[name], abs_error(got[name], ref[name]))
        # Fixed-mask ReLU+dropout chain rule; RNG semantics intentionally fixed.
        pre = rng.normal(size=(n, k))
        mask = (rng.random((n, k)) >= .5).astype(np.float64) / .5
        post = np.maximum(pre, 0) * mask
        got_post = stream_terminal(s, post, w, b, labels, plan)
        pret = torch.tensor(pre, dtype=torch.float64, requires_grad=True)
        postt = torch.relu(pret) * torch.tensor(mask)
        losst = F.cross_entropy((torch.tensor(s) @ postt) @ torch.tensor(w)
                                + torch.tensor(b), torch.tensor(labels))
        losst.backward()
        dz = got_post["dh"] * (pre > 0) * mask
        fixed_mask_dz_error = max(fixed_mask_dz_error, abs_error(dz, pret.grad.numpy()))
        for t in (np.zeros(m, dtype=bool), np.ones(m, dtype=bool), rng.random(m) < .5):
            mixed = mixed_forward_backward(s, h, w, b, labels, t)
            mixed_cases += 1
            for name in max_mixed:
                max_mixed[name] = max(max_mixed[name], abs_error(mixed[name], ref[name]))
    assert max(max_stream.values()) < ATOL
    assert max(max_mixed.values()) < ATOL
    assert fixed_mask_dz_error < ATOL

    mincut_cases = 80
    max_cut_error = 0.0
    exhaustive_masks = 0
    for _ in range(mincut_cases):
        m, n = 7, 9
        incidence = rng.random((m, n)) < .35
        neighbors = [np.flatnonzero(row).tolist() for row in incidence]
        a, b, c = rng.uniform(0, 20, m), rng.uniform(0, 10, m), rng.uniform(0, 8, n)
        cut, _ = mincut_choice(neighbors, a, b, c)
        exact = float("inf")
        for bits in itertools.product((False, True), repeat=m):
            exact = min(exact, model_cost(neighbors, a, b, c, np.array(bits)))
            exhaustive_masks += 1
        max_cut_error = max(max_cut_error, abs(exact - cut))
    assert max_cut_error < ATOL

    ns = [[0, 1, 2, 3]] * 4 + [[4, 6, 7, 8, 9, 10], [5, 11, 12, 13, 14, 15]]
    degree = np.array([len(x) for x in ns])
    k, d, g, sparse = 128, 32, 10.0, .05
    a, b, c = g + sparse * degree * k, sparse * degree * d, np.full(16, g)
    cost, chosen = mincut_choice(ns, a, b, c)
    greedy = np.array([b[v] + c[ns[v]].sum() < a[v] for v in range(6)])
    toy = {
        "units": "arbitrary nonnegative proxy-cost units, NOT runtime",
        "M": 6, "N": 16, "K": k, "D": d, "neighbors": ns,
        "all_aggregate": model_cost(ns, a, b, c, np.zeros(6, dtype=bool)),
        "all_transform": model_cost(ns, a, b, c, np.ones(6, dtype=bool)),
        "mincut_cost": cost, "transform_rows": np.flatnonzero(chosen).tolist(),
        "independent_row_greedy_cost": model_cost(ns, a, b, c, greedy),
        "independent_row_greedy_transform_rows": np.flatnonzero(greedy).tolist(),
    }

    theorem_graphs, theorem_masks = 60, 0
    min_dominance_gap = float("inf")
    for _ in range(theorem_graphs):
        n = 7
        adjacency = rng.random((n, n)) < .3
        np.fill_diagonal(adjacency, True)
        ns2 = [np.flatnonzero(row).tolist() for row in adjacency]
        deg = adjacency.sum(axis=1)
        for k, d in ((128, 32), (32, 128), (64, 64)):
            g, sparse = 7.3, .019
            a, b, c = g + sparse * deg * k, sparse * deg * d, np.full(n, g)
            best_uniform = min(model_cost(ns2, a, b, c, np.zeros(n, dtype=bool)),
                               model_cost(ns2, a, b, c, np.ones(n, dtype=bool)))
            for bits in itertools.product((False, True), repeat=n):
                gap = model_cost(ns2, a, b, c, np.array(bits)) - best_uniform
                min_dominance_gap = min(min_dominance_gap, gap)
                theorem_masks += 1
    assert min_dominance_gap >= -ATOL

    topology_rng = np.random.default_rng(SEED + 1)
    n, degree_n, community = 96, 6, 8
    blocked = np.zeros((n, n), dtype=float)
    random_graph = np.zeros_like(blocked)
    for v in range(n):
        own_group = np.arange((v // community) * community, (v // community + 1) * community)
        candidates = own_group[own_group != v]
        blocked[v, np.r_[v, topology_rng.choice(candidates, degree_n - 1, replace=False)]] = 1
        candidates = np.delete(np.arange(n), v)
        random_graph[v, np.r_[v, topology_rng.choice(candidates, degree_n - 1, replace=False)]] = 1
    natural, perm = np.arange(n), topology_rng.permutation(n)
    cases = [("community_grouped", blocked, natural),
             ("community_shuffled", blocked, perm),
             ("random_natural", random_graph, natural),
             ("random_shuffled", random_graph, perm)]
    frontier = []
    for name, mat, order in cases:
        p = compile_slots(mat, order)
        frontier.append({"case": name, "N": n, "M": n, "E": int(np.count_nonzero(mat)),
                         "row_degree": degree_n, "peak_live_slots": p.capacity,
                         "mean_live_slots": float(np.mean(p.active_counts)),
                         "used_sources": p.source_count,
                         "proposed_BF16_feature_FP32_adjoint_slot_bytes_K128": p.capacity * 6 * 128})

    # An intentionally simplified rounding example, NOT the TFS precision contract.
    quant_rng = np.random.default_rng(SEED + 2)
    s = torch.tensor(quant_rng.normal(size=(11, 13)), dtype=torch.float32)
    h = torch.tensor(quant_rng.normal(size=(13, 17)), dtype=torch.float32)
    w = torch.tensor(quant_rng.normal(size=(17, 7)), dtype=torch.float32)
    q = lambda x: x.to(torch.bfloat16).to(torch.float32)
    agg = q(s @ q(h)) @ q(w)
    trans = s @ q(q(h) @ q(w))
    bf16_difference = float((agg - trans).abs().max())

    return {
        "purpose": "Small mathematical references only; no native TFS/AMX execution or performance measurement.",
        "seed": SEED,
        "versions": {"numpy": np.__version__, "torch": torch.__version__, "networkx": nx.__version__},
        "tolerance": ATOL,
        "streaming_reference": {"cases": stream_cases, "max_absolute_errors": max_stream,
                                "fixed_mask_relu_dropout_dpre_max_error": fixed_mask_dz_error,
                                "one_source_load_and_interval_slot_invariants": "passed"},
        "mixed_association_reference": {"cases": mixed_cases, "max_absolute_errors": max_mixed},
        "mincut_vs_exhaustive": {"cases": mincut_cases, "enumerated_assignments": exhaustive_masks,
                                 "max_objective_error": max_cut_error},
        "synthetic_shared_cost_example": toy,
        "full_scope_uniform_cost_dominance": {"self_loop_graphs": theorem_graphs,
                                               "dimension_pairs_per_graph": 3,
                                               "enumerated_assignments": theorem_masks,
                                               "minimum_gap_mixed_minus_best_uniform": min_dominance_gap},
        "synthetic_frontier_widths": frontier,
        "simplified_BF16_order_max_difference_NOT_TFS": bf16_difference,
        "dropout_same_mask_probability_64_active_coordinates_p_half": float(2.0 ** -64),
        "all_assertions_passed": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("verification_results.json"))
    args = parser.parse_args()
    results = run_all()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
